"""
Predicting Medical Insurance Charges with Linear Regression
-------------------------------------------------------------
This script takes a different approach than the original notebook's
linear regression cell:

  - Instead of manually converting category -> dtype -> LabelEncoder
    (which forces an artificial 0/1/2/3 ORDER onto unordered categories
    like 'region'), this version uses a scikit-learn Pipeline with a
    ColumnTransformer + OneHotEncoder. This is the more standard,
    production-friendly way to handle categorical columns, and it
    avoids implying that, say, "northeast" < "southeast" numerically.
  - The whole workflow (encoding + scaling + regression) is wrapped in
    a single Pipeline object, so there's one '.fit()' and one
    '.predict()' call instead of separate encoding steps scattered
    through the notebook.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn import metrics

# ---------------------------------------------------------------
# 1. Load the data
# ---------------------------------------------------------------
df = pd.read_csv("insurance.csv")

# ---------------------------------------------------------------
# 2. Separate features (X) and target (y)
# ---------------------------------------------------------------
X = df.drop(columns=["charges"])
y = df["charges"]

numeric_features = ["age", "bmi", "children"]
categorical_features = ["sex", "smoker", "region"]

# ---------------------------------------------------------------
# 3. Build a preprocessing + model pipeline
#    - numeric columns get scaled
#    - categorical columns get one-hot encoded (drop='first' avoids
#      the "dummy variable trap" / redundant column)
# ---------------------------------------------------------------
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numeric_features),
        ("cat", OneHotEncoder(drop="first"), categorical_features),
    ]
)

model = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("regressor", LinearRegression()),
    ]
)

# ---------------------------------------------------------------
# 4. Train / test split (80% train, 20% test)
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=0
)

# ---------------------------------------------------------------
# 5. Fit the pipeline (handles encoding + scaling + regression in one call)
# ---------------------------------------------------------------
model.fit(X_train, y_train)

# ---------------------------------------------------------------
# 6. Inspect the learned coefficients
# ---------------------------------------------------------------
feature_names = model.named_steps["preprocessor"].get_feature_names_out()
coefficients = model.named_steps["regressor"].coef_
intercept = model.named_steps["regressor"].intercept_

print("Intercept (b0):", round(intercept, 2))
print("\nFeature coefficients:")
for name, coef in zip(feature_names, coefficients):
    print(f"  {name:25s} {coef:>10.2f}")

# ---------------------------------------------------------------
# 7. Evaluate on the held-out test set
# ---------------------------------------------------------------
y_pred = model.predict(X_test)

r2 = metrics.r2_score(y_test, y_pred)
mae = metrics.mean_absolute_error(y_test, y_pred)
mse = metrics.mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print("\nModel performance on test data:")
print(f"  R^2 score : {r2:.3f}")
print(f"  MAE       : {mae:,.2f}")
print(f"  RMSE      : {rmse:,.2f}")

# ---------------------------------------------------------------
# 8. Peek at a few actual vs predicted charges
# ---------------------------------------------------------------
comparison = pd.DataFrame({
    "Actual": y_test.values,
    "Predicted": np.round(y_pred, 2)
}).reset_index(drop=True)

print("\nActual vs Predicted (first 10 rows):")
print(comparison.head(10))

# ---------------------------------------------------------------
# 9. Save the full set of predictions to a CSV file
# ---------------------------------------------------------------
comparison.to_csv("charges_predictions.csv", index=False)
print("\nSaved all predictions to charges_predictions.csv")
