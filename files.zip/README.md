# Insurance Charges Prediction — Linear Regression

Predicts medical insurance `charges` from the classic
[insurance.csv](https://www.kaggle.com/datasets/mirichoi0218/insurance) dataset
using a scikit-learn `Pipeline` (OneHotEncoder + StandardScaler + LinearRegression).

## Files

- `linear_regression_charges.py` — main script: loads the data, trains the model,
  prints coefficients and evaluation metrics, and saves predictions to
  `charges_predictions.csv`.
- `insurance.csv` — dataset (age, sex, bmi, children, smoker, region, charges).

## Setup

```bash
pip install -r requirements.txt
```

## Usage

```bash
python linear_regression_charges.py
```

## Output

The script prints:
- Model intercept and feature coefficients
- R², MAE, and RMSE on a held-out test set
- A preview of actual vs. predicted charges

It also writes the full set of test-set predictions to `charges_predictions.csv`.
